/*! 
 *  script.aculo.us version <%= SCRIPTY2_VERSION %>
 *  (c) 2005-2009 Thomas Fuchs
 *
 *  script.aculo.us is freely distributable under the terms of an MIT-style license.
 *----------------------------------------------------------------------------------*/
 