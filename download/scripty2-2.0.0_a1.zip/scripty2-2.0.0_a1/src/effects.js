//= require <effects/base>
//= require <effects/heartbeat>
//= require <effects/queue>

//= require <effects/attribute>
//= require <effects/style>
//= require <effects/morph>
//= require <effects/parallel>
//= require <effects/scroll>

//= require <effects/transitions/transitions>
//= require <effects/transitions/penner>