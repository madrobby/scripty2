/** section: scripty2 ui
 *  class S2.UI.Behavior.Resize < S2.UI.Behavior
**/
S2.UI.Behavior.Resize = Class.create(S2.UI.Behavior, {
  initialize: function(element, options) {
  }
});