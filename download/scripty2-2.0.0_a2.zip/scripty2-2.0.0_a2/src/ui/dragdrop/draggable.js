var S2.UI.Draggable = Class.create({
  initialize: function(element, options){
    // ...
  }
});