S2.UI = {};

//= require "ui/dragdrop"